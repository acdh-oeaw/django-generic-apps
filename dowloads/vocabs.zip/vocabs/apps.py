from django.apps import AppConfig


class VocabsConfig(AppConfig):
    name = 'vocabs'
